//
//  Lesson_10App.swift
//  Lesson 10
//
//  Created by Lucas Chong on 18/9/23.
//

import SwiftUI

@main
struct Lesson_10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
