//
//  ContentView.swift
//  Lesson 10
//
//  Created by Lucas Chong on 18/9/23.
//

import SwiftUI
import SwiftPersistence

struct Math: Codable {
    var string: String
    var integer: Int
    var rational: Double
    var realnumber: Bool
}

struct Math2: Codable {
    var math: [Math]
    var difficult = true
}

struct ContentView: View {
    @Persistent("meth") var meth = Math(string: "WordProblem", integer: 69, rational: 4.20, realnumber: true)
    var body: some View {
        VStack {
            Text("String: \(meth.string)")
            Text("Integer: \(meth.integer)")
            Text("Double: \(meth.rational)")
            Text("RealNumber: \(meth.realnumber ? "true" : "false")")

        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
